import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JComponent;
import java.util.Random;

/**
 * This component draws tetrominos.
 */
public class TetrisComponent extends JComponent
{
  /**
   * Method to draw all tetromino shapes on the screen.
   *
   * @param g a graphics object
   */
  public void paintComponent(Graphics g)
  {
    // tetromino must be set before we can paint it.
    assert tetromino != null;

    Graphics2D g2 = (Graphics2D) g;
    tetromino.draw(g2);
	g2.setColor(GBGREEN);
    g2.drawRect(FRAMEX + 1, FRAMEY + 1, FRAMEWIDTH - 1, FRAMELENGTH - 1);
    
  }

  /**
   * Sets the current tetromino.
   *
   * @param piece a valid tetromino
   */
  public void setPiece(Tetromino piece){tetromino = piece;}
  
  /**
   * Moves tetromino
   * Up:
   * Rotate tetromino
   * 
   * Down:
   * Move tetromino closer to bottom
   * 
   * Left and right:
   * Move tetromino left and right
   * 
   * @param key press left or right
   */
  public void movePiece(KeyEvent e) {
	  if (e.getKeyCode() == KeyEvent.VK_UP)
	    	tetromino.rotateCCW90();
	  else if (e.getKeyCode() == KeyEvent.VK_DOWN) 
		    tetrY += tetromino.SIZE;
	  else if (e.getKeyCode() == KeyEvent.VK_LEFT && tetromino.getX() <= FRAMEX - tetromino.limitLeft())
		  tetromino.setX(tetrX);
	  else if (e.getKeyCode() == KeyEvent.VK_RIGHT && tetromino.getX() >= FRAMEWIDTH + Tetromino.SIZE - tetromino.limitRight())
		  tetromino.setX(tetrX);
	  else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
		  tetrX -= tetromino.SIZE;
		  tetromino.setX(tetrX);
	  }
	  else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
		  tetrX += tetromino.SIZE;
		  tetromino.setX(tetrX);
	  }
  }
  
  /** @return whether it's on the bottom or falling */
  public boolean isFalling() {
	  return falling;
  }
  
  /** Sees if the tetromino has touched the bottom.*/
  public void isGrounded() {
	  if (tetromino.getY() >= FRAMELENGTH - Tetromino.BLOCK + tetromino.limitDown()) {
		  falling = false;
		  tetromino.setY(FRAMEWIDTH + Tetromino.BLOCK + (2 * Tetromino.SIZE) + tetromino.limitDown());
	  }
  }
  
  /** Makes the block fall towards the bottom of the game screen.*/
  public void fallFallFall() {
	  if (falling && firstFall) {
		  tetromino.setY(tetromino.limitUp());
		  firstFall = false;
	  }
	  if (falling) {
		  tetrY += tetromino.SIZE;
		  tetromino.setY(tetrY);
	  }
  }
  
  private Tetromino tetromino;
  private boolean firstFall = true;
  private boolean falling = true;
  private static final int FRAMEX = 0;
  private static final int FRAMEY = 0;
  private static final int FRAMEWIDTH = Tetromino.SIZE * 10;
  private static final int FRAMELENGTH = FRAMEWIDTH * 2;
  private int tetrX = tetromino.SIZE;
  private int tetrY = tetromino.SIZE;
  final Color GBGREEN = new Color(155, 188, 15);
}

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Color;

/** Models an immutable tetromino. */
public class Tetromino
{
  /** Number of squares. */
  static public final int SQUARES = 4;

  /** Size of a tetromino square. */
  static public final int SIZE = 20;

  /** Size of the whole tetromino. */
  static public final int BLOCK = SQUARES * SIZE;

  /** Standard I sprite. */
  static public final int I = 0;

  /** Standard J sprite. */
  static public final int J = 1;

  /** Standard L sprite. */
  static public final int L = 2;

  /** Standard S sprite. */
  static public final int S = 3;

  /** Standard Z sprite. */
  static public final int Z = 4;

  /** Standard O sprite. */
  static public final int O = 5;

  /** Standard T sprite. */
  static public final int T = 6;

  /** number of sprites. */
  static public final int COUNT = T+1;

  /* Private constructor, because nobody should ever use an empty Tetromino! */
  private Tetromino() {}

  /**
   * Constructor to create a new tetromino.
   *
   * @param kind indicates the sprite to be constructed
   */
  public Tetromino(int kind)
  {
    // validate the input
    assert kind >= I && kind <= T;
    
    //stores kind for future reference
    this.kind = kind;

    // set default position
    x = y = 0;

    // set shape and color according to kind
    switch (kind)
    {
      case I:
        color = Color.CYAN;
        sprite = new int[][] { {0, 0, 0, 0},
                               {0, 0, 0, 0},
                               {1, 1, 1, 1},
                               {0, 0, 0, 0}
                             };
        break;

      case J:
        color = Color.ORANGE;
        sprite = new int[][] { {0, 0, 0, 0},
                               {1, 0, 0, 0},
                               {1, 1, 1, 0},
                               {0, 0, 0, 0}
                             };
        break;

      case L:
        color = Color.BLUE;
        sprite = new int[][] { {0, 0, 0, 0},
                               {0, 0, 1, 0},
                               {1, 1, 1, 0},
                               {0, 0, 0, 0}
                             };
        break;

      case S:
        color = Color.GREEN;
        sprite = new int[][] { {0, 0, 1, 0},
                               {0, 1, 1, 0},
                               {0, 1, 0, 0},
                               {0, 0, 0, 0}
                             };
        break;

      case Z:
        color = Color.RED;
        sprite = new int[][] { {0, 1, 0, 0},
                               {0, 1, 1, 0},
                               {0, 0, 1, 0},
                               {0, 0, 0, 0}
                             };
        break;

      case O:
        color = Color.YELLOW;
        sprite = new int[][] { {0, 0, 0, 0},
                               {0, 1, 1, 0},
                               {0, 1, 1, 0},
                               {0, 0, 0, 0}
                             };
        break;

      case T:
        color = Color.MAGENTA;
        sprite = new int[][] { {0, 0, 0, 0},
                               {0, 1, 0, 0},
                               {1, 1, 1, 0},
                               {0, 0, 0, 0}
                             };
        break;

      default:
        System.out.println("unexpected Tetromino");
        assert false;
    }

    // validate the object. after the constructor has run,
    //   the tetromino must be in a valid state and ready for use.

    // color must be a valid object
    assert color != null;

    // validate that sprite is a SQUARESxSQUARES array.
    assert sprite != null && sprite.length == SQUARES && sprite[0].length == SQUARES;
  }

  /**
   * Computes the original x coordinate of a rotated square at (x,y).
   *
   * @param x x-coordinate of the destination
   * @param y y-coordinate of the destination
   * @return an integer indicating the x coordinate of the source
   */
  private static int rotateX(int x, int y)
  {
    return 3-y;
  }

  /**
   * Computes the original y coordinate of a rotated square at (x,y).
   *
   * @param x x-coordinate of the destination
   * @param y y-coordinate of the destination
   * @return an integer indicating the y coordinate of the source
   */
  private static int rotateY(int x, int y)
  {
    return x;
  }

  /**
   * Rotates this tetromino counterclockwise by 90 degrees.
   */
  public void rotateCCW90()
  {
    int[][] rotated = new int[SQUARES][SQUARES];

    for (int i = 0; i < SQUARES; ++i)
      for (int j = 0; j < SQUARES; ++j)
        rotated[i][j] = sprite[rotateX(i,j)][rotateY(i,j)];

    sprite = rotated;
    rotation = rotation + 1;
  }

  /**
   * Convenience method to rotate a tetromino n number of times.
   *
   * @param n number of tetromino rotations
   *
   * @todo make code more efficient, by computing transformation once
   *       instead of n steps.
   */
  public void rotateCCW90(int n)
  {
    assert n >= 0 && n < 4; // at most 3 rotations

    if (n == 0) return; // no rotation needed

    rotateCCW90();      // rotate once
    rotateCCW90(n-1);   // rotate n-1 times
  }

  /**
   * Draws this tetromino at the given x and y coordinate.
   *
   * @param x x coordinate of the base point
   * @param y y coordinate of the base point
   * @param g2 graphics object
   */
  public void draw(Graphics2D g2)
  {
    for (int i = 0; i < SQUARES; ++i)
      for (int j = 0; j < SQUARES; ++j)
        if (sprite[i][j] != 0)
        {
          Rectangle filled = new Rectangle(x+i*SIZE+1, y+j*SIZE+1, SIZE-1, SIZE-1);
          Rectangle border = new Rectangle(x+i*SIZE,   y+j*SIZE,   SIZE,   SIZE);

          g2.setColor(color);
          g2.fill(filled);
          g2.setColor(Color.BLACK);
          g2.draw(border);
        }
  }

  /**
   * Sets x coordinate o tetromino.
   *
   * @param x new x-coordinate
   */
  public void setX(int x) { this.x = x; }

  /**
   * Sets y coordinate o tetromino.
   *
   * @param y new y-coordinate
   */
  public void setY(int y) { this.y = y; }
  
  /** gets x coordinate of tetromino*/
  public int getX() {return this.x;}
  
  /** gets y coordinate of tetromino */
  public int getY() {return this.y;}
  
  /**
   * Puts limits on block's movement downward.
   * 
   * @return amount by which block should be reigned back, going down
   */
  public int limitDown() {
	  if (kind == 5) {
		  return SIZE;
	  }
	  else if (kind == 0 && (rotation % 4) == 1) {
		  return 2 * SIZE;
	  }
	  else if (kind == 0 && (rotation % 4) == 3) {
		  return SIZE;
	  }
	  else if (kind == 1 && (rotation % 4) != 2) {
		  return SIZE;
	  }
	  else if (kind == 2 && (rotation % 4) != 3) {
		  return SIZE;
	  }
	  else if (kind == 3 && (rotation % 4) != 1) {
		  return SIZE;
	  }
	  else if (kind == 4 && (rotation % 4) != 1) {
		  return SIZE;
	  }
	  else if (kind == 6 && (rotation % 4) != 2) {
		  return SIZE;
	  }
	  return 0;
  }
  
  /**
   * Puts limits on block's movement leftward.
   * 
   * @return amount by which block should be reigned back, going left
   */
  public int limitLeft() {
	  if (kind == 5) {
		  return SIZE;
	  }
	  else if (kind == 0 && (rotation % 4) == 0) {
		  return 2 * SIZE;
	  }
	  else if (kind == 0 && (rotation % 4) == 2) {
		  return SIZE;
	  }
	  else if (kind == 1 && (rotation % 4) != 1) {
		  return SIZE;
	  }
	  else if (kind == 2 && (rotation % 4) != 1) {
		  return SIZE;
	  }
	  else if (kind == 3 && (rotation % 4) != 0) {
		  return SIZE;
	  }
	  else if (kind == 4 && (rotation % 4) != 0) {
		  return SIZE;
	  }
	  else if (kind == 6 && (rotation % 4) != 1) {
		  return SIZE;
	  }
	  return 0;
  }
  
  /**
   * Puts limits on block's movement rightward.
   * 
   * @return amount by which block should be reigned back, going right
   */
  public int limitRight() {
	  if (kind == 5) {
		  return 4 * SIZE;
	  }
	  else if (kind == 0 && (rotation % 4) == 0) {
		  return 4 * SIZE;
	  }
	  else if (kind == 0 && ((rotation % 4) == 1 || (rotation % 4) == 3)) {
		  return 5 * SIZE;
	  }
	  else if (kind == 0 && (rotation % 4) == 2) {
		  return 3 * SIZE;
	  }
	  else if (kind == 1 && ((rotation % 4) == 0 || (rotation % 4) == 1 || (rotation % 4) == 2)) {
		  return 4 * SIZE;
	  }
	  else if (kind == 1 && (rotation % 4) == 3) {
		  return 5 * SIZE;
	  }
	  else if (kind == 2 && ((rotation % 4) == 0 || (rotation % 4) == 1 || (rotation % 4) == 2)) {
		  return 4 * SIZE;
	  }
	  else if (kind == 2 && (rotation % 4) == 3) {
		  return 5 * SIZE;
	  }
	  else if (kind == 3 && ((rotation % 4) == 0 || (rotation % 4) == 1 || (rotation % 4) == 3)) {
		  return 4 * SIZE;
	  }
	  else if (kind == 3 && (rotation % 4) == 2) {
		  return 5 * SIZE;
	  }
	  else if (kind == 4 && ((rotation % 4) == 0 || (rotation % 4) == 1 || (rotation % 4) == 3)) {
		  return 4 * SIZE;
	  }
	  else if (kind == 4 && (rotation % 4) == 2) {
		  return 5 * SIZE;
	  }
	  else if (kind == 6 && ((rotation % 4) == 0 || (rotation % 4) == 1 || (rotation % 4) == 2)) {
		  return 4 * SIZE;
	  }
	  else if (kind == 6 && (rotation % 4) == 3) {
		  return 5 * SIZE;
	  }
	  return 0;
  }

  /**
   * Puts limit on where block spawns at top
   * 
   * @return amount block can go up
   */
  public int limitUp() {
	  if (kind == 0 || kind == 1 || kind == 2 || kind == 6) {
		 return SIZE; 
	  }
	  if (kind == 3 || kind == 4 || kind == 5) {
		  return 2 * SIZE;
	  }
	  return 0;
  }
  /** A matrix representing the tetromino's sprite. */
  private int[][] sprite;

  /** x coordinate. */
  private int x;

  /** y coordinate. */
  private int y;

  /** The tetromino's color. */
  private Color color;
  
  /** Kind of tetromino */
  private int kind;
  
  /** Orientation of tetromino */
  private int rotation = 0;
}

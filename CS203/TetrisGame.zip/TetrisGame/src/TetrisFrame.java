import java.util.Random;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.Timer;

public class TetrisFrame extends JFrame {
	private static final long serialVersionUID = 1L;
	private Random rand = new Random();
    private Tetromino piece = new Tetromino(rand.nextInt(Tetromino.COUNT));
    private TetrisComponent comp = new TetrisComponent();
    
    public TetrisFrame () {
	    comp.setPiece(piece);
	    piece.setX(piece.SIZE);
	    piece.setY(piece.SIZE - piece.limitUp());
	    add(comp);
	    comp.addKeyListener(new KeyListener() {
			public void keyPressed(KeyEvent e) {
				if (comp.isFalling()) {comp.movePiece(e); comp.repaint();} else {;}
			}
			@Override
			public void keyReleased(KeyEvent arg0) {}
			@Override
			public void keyTyped(KeyEvent arg0) {}
	    });
	    
	    int timerDelay = 1000;
		new Timer(timerDelay, e -> {
			comp.isGrounded();
			comp.fallFallFall();
			comp.repaint();
		}).start();
	    
		comp.setFocusable(true);
		comp.requestFocus();
    }
}

import javax.swing.JFrame;

/** A simple tetromino player. */
public class TetrisViewer {
  /** size of frame. */
  private static final int FRAMEX = (Tetromino.SIZE * 10) + 15;
  private static final int FRAMEY = (2 * FRAMEX) + 10;

  /**
   * The main method.
   *
   * @param args command line arguments; currently ignored.
   */
  public static void main(String[] args)
  {
	// create and setup frame
    JFrame frame  = new TetrisFrame();

    frame.setSize(FRAMEX, FRAMEY);
    frame.setTitle("Tetromino");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setVisible(true);
  }
}

import java.util.Random;
import java.awt.geom.Rectangle2D;
import javax.swing.JComponent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class TetrisComponent extends JComponent{

	private static final long serialVersionUID = 5094840333818119396L;
	public void paintComponent(Graphics g) {
		Integer[] shapes = {1, 2, 3, 4, 5, 6, 7};
		Random shapeChoice = new Random();
		int shape = shapeChoice.nextInt(shapes.length);
		Integer[] turns = {0, 90, 180, 270};
		Random turnChoice = new Random();
		int orientation = turnChoice.nextInt(turns.length);
		Color PURPLE = new Color(255, 0, 255);
		Graphics2D g2 = (Graphics2D) g;
		if (shape == 1) {g2.setColor(Color.YELLOW);}
		else if (shape == 2) {g2.setColor(Color.BLUE);}
		else if (shape == 3) {g2.setColor(Color.ORANGE);}
		else if (shape == 4) {g2.setColor(Color.GREEN);}
		else if (shape == 5) {g2.setColor(Color.RED);}
		else if (shape == 6) {g2.setColor(PURPLE);}
		else if (shape == 7) {g2.setColor(Color.CYAN);}
		Rectangle2D.Double[] tetr = setTetromino(shape, orientation);
		for (int i = 0; i < tetr.length; i++) {
			g2.fill(tetr[i]);
			g2.draw(tetr[i]);
		}
	}
	public Rectangle2D.Double[] setTetromino (int shape, int orientation)
	{
		/*
		 * 
		 * Despite the name, this creates objects; it doesn't set them.
		 * @param shape: chooses which shape of tetromino to draw
		 * @param orientation: was supposed to choose orientation of the tetromino
		 * @return an array of rectangles arranged in a tetromino shape
		 */
		int boxint = randomIntegerMaker();
		int randx = randomIntegerMaker() + 50;
		int randy = randomIntegerMaker() + 50;
		double angle = Math.PI * orientation; //I couldn't even get this to work before I gave up; if multiplied by a non-multiple-of-two, a square simply wouldn't appear
		switch(shape) {
				
			case 1: //draws an O tetromino
				Rectangle2D.Double Otetr1 = new Rectangle2D.Double(randx, randy, boxint, boxint);
				Rectangle2D.Double Otetr2 = new Rectangle2D.Double(randx + boxint, randy, boxint, boxint);
				Rectangle2D.Double Otetr3 = new Rectangle2D.Double(randx, randy + boxint, boxint, boxint);
				Rectangle2D.Double Otetr4 = new Rectangle2D.Double(randx + boxint, randy  + boxint, boxint, boxint);
				Rectangle2D.Double[] O = {Otetr1, Otetr2, Otetr3, Otetr4};
				return O;

			case 2: //draws J tetromino
				Rectangle2D.Double Jtetr1 = new Rectangle2D.Double(randx, randy, boxint, boxint);
				Rectangle2D.Double Jtetr2 = new Rectangle2D.Double(randx  + boxint, randy, boxint, boxint);
				Rectangle2D.Double Jtetr3 = new Rectangle2D.Double(randx  + boxint + boxint, randy, boxint, boxint);
				Rectangle2D.Double Jtetr4 = new Rectangle2D.Double(randx  + boxint + boxint, randy  + boxint, boxint, boxint);
				Rectangle2D.Double[] J = {Jtetr1, Jtetr2, Jtetr3, Jtetr4};
				return J;

			case 3: //draws L tetromino
				Rectangle2D.Double Ltetr1 = new Rectangle2D.Double(randx, randy, boxint, boxint);
				Rectangle2D.Double Ltetr2 = new Rectangle2D.Double(randx, randy  + boxint, boxint, boxint);
				Rectangle2D.Double Ltetr3 = new Rectangle2D.Double(randx, randy  + boxint + boxint, boxint, boxint);
				Rectangle2D.Double Ltetr4 = new Rectangle2D.Double(randx  + boxint, randy  + boxint + boxint, boxint, boxint);
				Rectangle2D.Double[] L = {Ltetr1, Ltetr2, Ltetr3, Ltetr4};
				return L;

			case 4: //draws S tetromino
				Rectangle2D.Double Stetr1 = new Rectangle2D.Double(randx, randy, boxint, boxint);
				Rectangle2D.Double Stetr2 = new Rectangle2D.Double(randx  + boxint, randy, boxint, boxint);
				Rectangle2D.Double Stetr3 = new Rectangle2D.Double(randx  + boxint, randy - boxint, boxint, boxint);
				Rectangle2D.Double Stetr4 = new Rectangle2D.Double(randx  + boxint + boxint , randy - boxint, boxint, boxint);
				Rectangle2D.Double[] S = {Stetr1, Stetr2, Stetr3, Stetr4};
				return S;
					
			case 5: //draws Z tetromino
				Rectangle2D.Double Ztetr1 = new Rectangle2D.Double(randx, randy, boxint, boxint);
				Rectangle2D.Double Ztetr2 = new Rectangle2D.Double(randx  + boxint, randy, boxint, boxint);
				Rectangle2D.Double Ztetr3 = new Rectangle2D.Double(randx  + boxint, randy  + boxint, boxint, boxint);
				Rectangle2D.Double Ztetr4 = new Rectangle2D.Double(randx  + boxint + boxint, randy  + boxint, boxint, boxint);
				Rectangle2D.Double[] Z = {Ztetr1, Ztetr2, Ztetr3, Ztetr4};
				return Z;

			case 6: //draws T tetromino
				Rectangle2D.Double Ttetr1 = new Rectangle2D.Double(randx, randy, boxint, boxint);
				Rectangle2D.Double Ttetr2 = new Rectangle2D.Double(randx  + boxint, randy, boxint, boxint);
				Rectangle2D.Double Ttetr3 = new Rectangle2D.Double(randx  + boxint, randy  + boxint, boxint, boxint);
				Rectangle2D.Double Ttetr4 = new Rectangle2D.Double(randx  + boxint + boxint, randy, boxint, boxint);
				Rectangle2D.Double[] T = {Ttetr1, Ttetr2, Ttetr3, Ttetr4};
				return T;

			case 7: //draws I tetromino
				Rectangle2D.Double Itetr1 = new Rectangle2D.Double(randx, randy, boxint, boxint);
				Rectangle2D.Double Itetr2 = new Rectangle2D.Double(randx  + boxint, randy, boxint, boxint);
				Rectangle2D.Double Itetr3 = new Rectangle2D.Double(randx  + boxint + boxint, randy, boxint, boxint);
				Rectangle2D.Double Itetr4 = new Rectangle2D.Double(randx  + boxint + boxint + boxint, randy, boxint, boxint);
				Rectangle2D.Double[] I = {Itetr1, Itetr2, Itetr3, Itetr4};
				return I;
			default:
				Rectangle2D.Double norect = new Rectangle2D.Double(0,0,0,0);
				Rectangle2D.Double[] empty = {norect};
				return empty;
		}
	}
	public int randomIntegerMaker()
	{
		/*
		 * Generates random integer within reasonable bounds
		 * @return: a random integer
		 */
		Random x = new Random();
		int y = x.nextInt();
		if (y < 40){while (y < 40){y += 1;}}
		else if (y > 100){while (y > 100){y -= 1;}}
		return y;
	}
}
import javax.swing.JFrame;

public class TetrisViewer {
static int SCREENSQUARE = 1000;
	public static void main(String[] args) {
		JFrame gameScreen = new JFrame();
		gameScreen.setSize(SCREENSQUARE, SCREENSQUARE);
	    gameScreen.setTitle("AHH BLOCKS ARE FALLING");
	    gameScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    TetrisComponent tetromino = new TetrisComponent();
	    gameScreen.add(tetromino);
	    gameScreen.setVisible(true);
	}

}

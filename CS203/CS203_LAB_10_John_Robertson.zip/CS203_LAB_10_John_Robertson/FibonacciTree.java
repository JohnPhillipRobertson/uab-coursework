public class FibonacciTree {
	public static void main(String[] args) {
		fibTree(5, 0);
	}
	public static int fibTree(int n, int tabs) {
		if (n <= 1) {
			for (int i = 0; i < tabs; i++) System.out.print('\t');
			if (n == 0) System.out.println("fib(0)-->0");
			else System.out.println("fib(1)-->1");
			return n;
		}
		int result = fibTree(n-1, tabs + 1);
		for (int i = 0; i<tabs; i++) System.out.print('\t');
		System.out.println("fib(" + n + ")");
		result += fibTree(n-2, tabs + 1);
		return result;
	}
	public static long fib(int n) {
		if (n == 0) {return 0;}
		else if (n == 1) {return 1;}
		else {return fib(n-1) + fib(n-2);}
	}
}
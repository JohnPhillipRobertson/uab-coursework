
import javax.swing.JFrame;
import javax.swing.Timer;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * the frame contains a frogger game.
 */
public class FroggerFrame extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private FroggerComponent component;
	
	/**
	 * construct the frame		
	 */
	public FroggerFrame() {
		
		component = new FroggerComponent();
		add(component);
		
		component.addKeyListener(new KeyListener() {
			public void keyPressed(KeyEvent e) {
				component.moveFrogLocation(e);
				component.repaint();
			}
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		int timerDelay = 500;
		new Timer(timerDelay, e -> {
			component.Move();
			component.repaint();
		}).start();
		
		
		component.setFocusable(true);
		component.requestFocus();
	}	
}


package ch.makery.address.model;

interface Visitor {
	public abstract double visit(Component c);
		
}
